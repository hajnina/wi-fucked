Dirty -> Wi-Fucked brand rename: CI workflow files only
========================================================

Everything else in the rename landed on branch
claude/brand-rename-dirty-wifucked-8hl4m5. These three GitHub Actions
workflow files could NOT be pushed from that session: the git push was
rejected with

  refusing to allow an OAuth App to create or update workflow
  `.github/workflows/ci.yml` without `workflow` scope

This is a GitHub restriction on the OAuth app/token used by the session,
not a repo problem. A human (or a token with the `workflow` scope) needs
to apply these by hand.

Contents:
  - dirty-to-wifucked-workflows.patch  -- unified diff, apply with:
        git apply dirty-to-wifucked-workflows.patch
    (from repo root, on top of the commit that renamed everything else)
  - ci.yml, main_release.yml, reusable_image_pipeline.yml
        -- full post-rename contents of each file, for a direct copy-paste
           if the patch doesn't apply cleanly after other changes land.

All three files only have Dirty/DIRTY/dirty -> Wi-Fucked/WI-FUCKED/wifucked
text substitutions (same as the rest of the codebase) -- no other logic
changed.
